#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct Node{
  char rank;
  char username[255];
  long long int point;
  int height, bf;
  Node *left, *right;
};

Node *root = NULL;

Node *createNewData(const char rank, const char username[], long long int point)
{
  Node *newData = (Node *)malloc(sizeof(Node));
  newData->rank = rank;
  strcpy(newData->rank, rank);
  newData->point = point;
  newData->bf = 0;
  newData->left = NULL;
  newData->right = NULL;
  return newData;
}

int max(int left, int right)
{
  if(left > right) return left;
  else return right;
}

int height(Node *curr)
{
  if(curr == NULL) return 0;
  return curr->height;
}

int getBf(Node *curr)
{
  if(curr == NULL) return 0;
  else return height(curr->left) - height(curr->right);
}

Node *updateBF(Node *curr)
{
  curr->height = 1 + max(height(curr->left), height(curr->right));
  curr->bf = height(curr->left) - height(curr->right);
  return curr;
}

Node *leftRotate(Node *curr)
{
  Node *x = curr->right;
  Node *temp = x->left;
  x->left = curr;
  curr->right = temp;
  curr = updateBF(curr);
  x = updateBF(x);
  return x;
}

Node *rightRotate(Node *curr)
{
  Node *x = curr->left;
  Node *temp = x->right;
  x->right = curr;
  curr->left = temp;
  curr = updateBF(curr);
  x = updateBF(x);
  return x;
}

Node *selfBalancing(Node *curr)
{
  if (curr->bf > 1 && curr->left->bf > 0)
  {
    return rightRotate(curr);
  }
  else if (curr->bf > 1 && curr->left->bf < 0)
  {
    curr->left = leftRotate(curr->left);
    return rightRotate(curr);
  }
  else if (curr->bf < -1 && curr->right->bf < 0)
  {
    return leftRotate(curr);
  }
  else if (curr->bf < -1 && curr->right->bf > 0)
  {
    curr->right = rightRotate(curr->right);
    return leftRotate(curr);
  }
  return curr;
}

Node *insert(Node *curr, const char rank, const char username[], long long int point)
{
  if (curr == NULL)
  {
    curr = createNewData(rank, username, point);
  }
  else if (strcmp(username, curr->username) < 0)
  {
    curr->left = insert(curr->left, rank, username, point);
  }
  else if (strcmp(username, curr->username) > 0)
  {
    curr->right = insert(curr->right, rank, username, point);
  }
  else return curr;
  return selfBalancing(updateBF(curr));
}

Node *search(Node *curr, const char target[])
{
  if(curr == NULL) return NULL;
  else if (strcmp(target, curr->username) < 0)
  {
    return search(curr->left, target);
  }
  else if (strcmp(target, curr->username) > 0)
  {
    return search(curr->right, target);
  }
  else if (strcmp(target, curr->username) == 0)
  {
    return curr;
  }
}

Node *getPredecessor(Node *curr)
{
    Node *temp = curr->left;
    while (temp->right!=NULL)
    {
        temp = temp->right;
    }
    return temp;
}

Node *removeNode(Node *curr, char target[])
{
  if(curr == NULL) return curr;
  else if (strcmp(target, curr->username) < 0)
  {
    curr->left = removeNode(curr->left, target);
  }
  else if (strcmp(target, curr->username) > 0)
  {
    curr->right = removeNode(curr->right, target);
  }
  else
  {
    if (curr->left == NULL && curr->right == NULL)
    {
      free(curr);
      curr = NULL;
      return NULL;
    }
    else if (curr->left == NULL || curr->right == NULL)
    {
      Node *temp = curr->right ? curr->right : curr->left;
      curr = temp;
      return curr;
    }
    else if (curr->left != NULL && curr->right != NULL)
    {
      Node *temp = getPredecessor(curr->left);
      strcpy(curr->username, temp->username);
      curr->left = removeNode(curr->left, temp->username);
    }
  }
  return selfBalancing(updateBF(curr));
}
int main()
{
  
}
